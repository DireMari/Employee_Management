<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login_user.php');
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'employee_management');
$id = $_GET['id'];

$id = intval($id);
$conn->query("DELETE FROM employees WHERE id=$id");

header('Location: employees.php'); 
exit;
?>
