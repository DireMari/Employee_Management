<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login_user.php');
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'employee_management');
$id = $_GET['id'];
$conn->query("DELETE FROM users WHERE id=$id");
header('Location: dashboard.php');
exit;
?>
